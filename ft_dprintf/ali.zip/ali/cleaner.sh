#!/bin/sh
rm -f destroyer
rm -f cft.pf
rm -f crl.pf
rm -f dft.pf
rm -f drl.pf
rm -f oft.pf
rm -f orl.pf
rm -f pft.pf
rm -f prl.pf
rm -f uft.pf
rm -f url.pf
rm -f x.ft.pf
rm -f x.rl.pf
rm -f x_ft.pf
rm -f x_rl.pf
rm -f xft.pf
rm -f xrl.pf
