# ft_printf_destroyer
42 ft_printf tester

Still working on it

put your libftprintf.a and
run ./death.sh to test your ft_printf()
