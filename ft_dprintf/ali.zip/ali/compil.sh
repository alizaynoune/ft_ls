#!/bin/sh
gcc -o destroyer main_ft_printf.c libftprintf.a
#gcc -Wall -Werror -Wextra -o destroyer main_ft_printf.c libftprintf.a
